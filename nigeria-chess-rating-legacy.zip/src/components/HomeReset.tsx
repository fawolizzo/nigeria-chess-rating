
import React from "react";

// This is an empty component that no longer renders anything
const HomeReset: React.FC = () => {
  return null;
};

export default HomeReset;
