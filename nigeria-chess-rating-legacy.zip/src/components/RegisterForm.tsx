
import RegisterForm from "@/components/register/RegisterForm";

// Re-export the RegisterForm component for backward compatibility
export default RegisterForm;
