
// Reserved for further logic if the completed tab grows in complexity. For now, just a placeholder.
import React from "react";
import { OrganizerTabPanel } from "../OrganizerTabPanel";

export function OrganizerCompletedTab(props: any) {
  return <OrganizerTabPanel {...props} />;
}
