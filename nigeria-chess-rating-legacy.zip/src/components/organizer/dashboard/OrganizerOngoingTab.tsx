
// Reserved for further logic if the ongoing tab grows in complexity. For now, just a placeholder.
import React from "react";
import { OrganizerTabPanel } from "../OrganizerTabPanel";

export function OrganizerOngoingTab(props: any) {
  return <OrganizerTabPanel {...props} />;
}
