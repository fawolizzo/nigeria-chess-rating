
// Reserved for further logic if the pending tab grows in complexity. For now, just a placeholder.
import React from "react";
import { OrganizerTabPanel } from "../OrganizerTabPanel";

export function OrganizerPendingTab(props: any) {
  return <OrganizerTabPanel {...props} />;
}
