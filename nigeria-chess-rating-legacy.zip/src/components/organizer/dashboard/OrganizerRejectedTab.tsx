
// Reserved for further logic if the rejected tab grows in complexity. For now, just a placeholder.
import React from "react";
import { OrganizerTabPanel } from "../OrganizerTabPanel";

export function OrganizerRejectedTab(props: any) {
  return <OrganizerTabPanel {...props} />;
}
