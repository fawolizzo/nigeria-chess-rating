
// Reserved for further logic if the upcoming tab grows in complexity. For now, just a placeholder.
import React from "react";
import { OrganizerTabPanel } from "../OrganizerTabPanel";

export function OrganizerUpcomingTab(props: any) {
  return <OrganizerTabPanel {...props} />;
}
