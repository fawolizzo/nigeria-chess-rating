
/**
 * This file re-exports the refactored UserContext for backward compatibility
 */
export { UserProvider, useUser } from './user';
