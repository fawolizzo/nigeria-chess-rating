
// Re-export from the registration folder for backward compatibility
export { useRegisterForm } from './registration/useRegisterForm';
