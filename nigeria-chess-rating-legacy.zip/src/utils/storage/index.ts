
// Re-export all storage utilities for backward compatibility
export * from './basicStorage';
export * from './deviceIdentity';
export * from './storageSync';
export * from './storageDiagnostics';
